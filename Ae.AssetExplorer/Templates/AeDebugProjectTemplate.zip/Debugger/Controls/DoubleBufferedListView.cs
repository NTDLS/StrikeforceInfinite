namespace Ae.Engine.Debug.Debugger.Controls
{
    class DoubleBufferedListView : System.Windows.Forms.ListView
    {
        public DoubleBufferedListView()
        {
            DoubleBuffered = true;
        }
    }
}
