﻿using Ae.Engine;
using Ae.Engine.Hardware;
using Ae.Engine.Mathematics;

namespace Ae.Engine.Debug
{
    public partial class FormRender
        : Form
    {
        private readonly AeEngine _engine;

        public FormRender()
        {
            InitializeComponent();

            SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.Opaque | ControlStyles.ResizeRedraw | ControlStyles.UserPaint, true);

            var settings = AeEngine.LoadSettings();

            var screen = Screen.FromPoint(Cursor.Position);

            this.CenterFormOnScreen(screen, settings.Resolution);

            var drawingSurface = new Control
            {
                Dock = DockStyle.Fill
            };
            Controls.Add(drawingSurface);

            _engine = new AeEngine(drawingSurface,
                AeEngineExecutionMode.AttachedDebugging, assetPackagePath: @"##ASSETS_FULL_PATH##");

            //_engine.EnableDevelopment(new FormInterrogation(_engine));

            Shown += (object? sender, EventArgs e) => Task.Run(() =>
            {
                var loadingDetail = _engine.Sprites.TextBlocks.Add(_engine.Rendering.TextFormats.Loading,
                    _engine.Rendering.Materials.Brushes.OrangeRed, new AeVector(100, 100), true);

                void EngineStartupProgressCallback(string message, float progress)
                {
                    loadingDetail?.SetTextAndCenterX($"{message} ({progress:n0}%)");
                }

                _engine.StartEngine(EngineStartupProgressCallback);

                loadingDetail.QueueForDelete();
            });

            drawingSurface.GotFocus += (object? sender, EventArgs e) => _engine.Display.SetIsDrawingSurfaceFocused(true);
            drawingSurface.LostFocus += (object? sender, EventArgs e) => _engine.Display.SetIsDrawingSurfaceFocused(false);

            drawingSurface.KeyUp += FormRenderTarget_KeyUp;
        }

        private void FormRenderTarget_KeyUp(object? sender, KeyEventArgs e)
        {
            _engine.Input.HandleSingleKeyPress(e.KeyCode);

            if (e.KeyCode == Keys.Escape)
            {
                //We do not want the escape key to interrupt menus.
                if (_engine.Menus.Current?.HandlesEscape() != true)
                {
                    _engine.Pause();

                    if (MessageBox.Show("Are you sure you want to quit?", AeConstants.FriendlyName,
                        MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
                    {
                        Close();
                    }
                    else
                    {
                        _engine.Resume();
                    }
                }
            }
        }
    }
}
