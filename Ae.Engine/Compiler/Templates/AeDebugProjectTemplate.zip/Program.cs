﻿namespace Ae.Engine.Debug
{
    internal class Program
    {
        public static void Main(string[] args)
        {
            Application.Run(new FormRender());
        }
    }
}
